# Pharmahackathon 2018

Requires installation of R.

For overview, analysis results, discussion, and conclusion, please see the PPTX presentation file.


To run
1. Download dataset from https://drive.google.com/file/d/1QHFueacItaG-ODc__lBwMr2hGKj0T1yX/view?usp=sharing
2. Create a "./data" directory relative to the R script.
3. Unzip datafiles into "./data" directory.
4. Run R script
