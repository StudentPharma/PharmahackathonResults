from Bio import SeqIO
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from scipy.ndimage.filters import gaussian_filter
from pathlib import Path
import os

def generateMatrix(seq1, seq2):
    AAColors = ({"aliphatic":(192, 57, 43),
              "aromatic":(46, 204, 113),
              "acidic":(230, 126, 34),
             "basic":(52, 152, 219),
             "hydroxylic":(155, 89, 182),
             "sulfur":(241, 196, 15),
             "amidic":(25, 42, 86)})
    seq1 = str(seq1)
    seq2 = str(seq2)
    matrix = np.zeros((len(seq1),len(seq2),3), dtype = int)

    for i in range(len(seq1)):

        for j in range(len(seq2)):
            if seq1[i] == seq2[j]:
                AAType = getAAType(seq1[i])
                color = AAColors[AAType]
                matrix[i,j] = np.asarray(color)
            else:
                matrix[i,j] = np.asarray((24, 32, 40))
    return matrix




def getAAType(oneLetterAA):
    if oneLetterAA in ["F","W","Y"]:
        return "aromatic"
    elif oneLetterAA in ["D","E"]:
        return "acidic"
    elif oneLetterAA in ["R","H","K"]:
        return "basic"
    elif oneLetterAA in ["S", "T"]:
        return "hydroxylic"
    elif oneLetterAA in ["C", "M"]:
        return "sulfur"
    elif oneLetterAA in ["N", "Q"]:
        return "amidic"
    else:
        return "aliphatic"



def extractGene(gene):
    """given path, returns the sequence and the description"""
    twoPart = gene.split("/")
    path = Path(os.path.dirname(os.path.realpath(__file__))) / "uploads" / twoPart[0]
    a = list(SeqIO.parse(path, "fasta"))
    for sequence in a:
        if sequence.description == twoPart[1]:
            return (str(sequence.seq), twoPart[1])


def findNextNumber(fileExtension):
    """Given a file extension, gives the next number"""
    p = Path(os.path.dirname(os.path.realpath(__file__))) / "static"
    maximum = -1
    for subP in p.glob("*." + fileExtension):
        if str(subP.stem).isdigit():
            if int(str(subP.stem)) > maximum:
                maximum = int(str(subP.stem))
    return maximum + 1

def makeTheGraph(gene1, gene2):
    """Given two genes references, figures saves the graph for it"""
    gene1, desc1 = extractGene(gene1)
    gene2, desc2 = extractGene(gene2)

    number = findNextNumber("svg")

    m = generateMatrix(gene1,gene2)
    plt.figure()
    plt.tight_layout()
    plt.imshow(m)

    plt.ylabel(desc1)
    plt.xlabel(desc2)
    url = Path(os.path.dirname(os.path.realpath(__file__))) / "static" / (str(number)+".svg")
    plt.savefig(url)
    plt.close()
    return str(url)


def getListOfFiles():
    """Returns a list of all the sequences within uploads"""
    f = Path(os.path.dirname(os.path.realpath(__file__))) / "uploads"

    listOfFasta = list(f.glob("*.fasta"))
    finalList = []
    for fasta in listOfFasta:
        a = list(SeqIO.parse(fasta, "fasta"))

        for sequence in a:
            finalList.append(fasta.name + "/" + sequence.description)
    return finalList
