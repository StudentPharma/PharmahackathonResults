from flask import Flask, flash, redirect, render_template, request, session, abort, redirect, url_for
from random import randint
import os
from werkzeug.utils import secure_filename
from pathlib import Path

#Custom Module
from visualizerLibrary import *

#Launching the App
app = Flask(__name__)

# Getting the current path to setup the upload folder
dir_path = os.path.dirname(os.path.realpath(__file__))
UPLOAD_FOLDER = dir_path+'/uploads'
ALLOWED_EXTENSIONS = set(['fasta'])

# Configuring Flask Upload Folder
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


def allowed_file(filename):
    """
    Returns the file types which are allowed
    """
    return '.' in filename and \
           filename.rsplit('.', 1)[1] in ALLOWED_EXTENSIONS


@app.route("/index")
@app.route("/")
def index():
    return render_template('index.html')



@app.route("/upload", methods=['GET', 'POST'])
def upload():
    displayParam = "display:none"

    if request.method == 'POST' and 'file' in request.files:
        file = request.files['file']
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            #return redirect(url_for('index'))
            displayParam = ""
    return render_template('upload.html', display = displayParam)


@app.route("/visualize")
def visualize():
    displayImg = "display:none"
    url = ""
    if not (request.args.get("gene1") is None) and request.args["gene1"] != "none" and request.args["gene2"] != "none":
        # Create the visualization
        gene1, gene2 = str(request.args["gene1"]), str(request.args["gene2"])
        url = makeTheGraph(gene1, gene2)
        displayImg = ""

    listOfFile = getListOfFiles()
    #return str(listOfFile)
    #return str(genesList)
    url = "static/"+Path(url).name

    return render_template('visualize.html', imgurl = url, genesList = listOfFile, display = displayImg)

#@app.route("/hello/<string:name>")
@app.route("/hello/<string:name>/")
def hello(name):
#    return name
    quotes = [ "'If people do not believe that mathematics is simple, it is only because they do not realize how complicated life is.' -- John Louis von Neumann ",
               "'Computer science is no more about computers than astronomy is about telescopes' --  Edsger Dijkstra ",
               "'To understand recursion you must first understand recursion..' -- Unknown",
               "'You look at things that are and ask, why? I dream of things that never were and ask, why not?' -- Unknown",
               "'Mathematics is the key and door to the sciences.' -- Galileo Galilei",
               "'Not everyone will understand your journey. Thats fine. Its not their journey to make sense of. Its yours.' -- Unknown"  ]
    randomNumber = randint(0,len(quotes)-1)
    quote = quotes[randomNumber]

    return render_template(
        'test.html',**locals())

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=80, debug=True)
